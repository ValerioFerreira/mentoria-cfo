---
id: S0473
agente: CODEX-L1
materia: Direito Administrativo
aula: Aula 09 — Agentes públicos: espécies e classificação, poderes, deveres e prerrogativas, cargo, emprego e função
trecho: direito-administrativo/a09/s11
paginas_lidas: 106-117
---
# ANALÍTICO

A Constituição proíbe, como regra, a acumulação remunerada de vínculos públicos, mas prevê exceções taxativas condicionadas à compatibilidade de horários. Também disciplina o exercício de mandato eletivo por servidor e o pagamento por subsídio.

### Acumulação remunerada

O art. 37, XVI e XVII, da Constituição estende a vedação a cargos, empregos e funções em toda a Administração direta e indireta, incluindo subsidiárias e sociedades controladas pelo poder público. A proibição não impede, por si, vínculo público acumulado com emprego privado, desde que não haja outra incompatibilidade.

Admite-se acumular, havendo compatibilidade de horários: **dois cargos de professor**; **um cargo de professor com outro técnico ou científico**; ou **dois cargos ou empregos privativos de profissionais de saúde com profissões regulamentadas**. A compatibilidade deve ser real e permitir o cumprimento integral das jornadas; não basta que os horários não coincidam formalmente. A Constituição também estende essas regras a empregos e funções e permite acumulação remunerada nas hipóteses constitucionais aplicáveis a militares e profissionais da saúde.

### Mandato eletivo e subsídio

Servidor investido em mandato federal, estadual ou distrital afasta-se do cargo. No mandato de prefeito, também se afasta, podendo optar pela remuneração. Vereador pode manter o cargo se houver compatibilidade de horários; se incompatível, afasta-se e pode optar pela remuneração do cargo (CF, art. 38). O tempo de serviço conta para efeitos legais, com exceções constitucionais quanto à promoção por merecimento e ao regime previdenciário.

O **subsídio** é parcela única, vedado acréscimo de gratificações, adicionais, abonos ou verbas remuneratórias, ressalvadas parcelas indenizatórias legítimas. A denominação formal não resolve: importa a natureza efetiva da parcela. Benefício chamado de indenização, mas pago de modo habitual sem ressarcir despesa, pode ser remuneratório e incompatível com o subsídio. A vedação constitucional busca transparência e impede que parcelas artificiais contornem a estrutura remuneratória definida em lei.

As exceções são taxativas e devem ser interpretadas em conjunto com a regra de compatibilidade: a Administração precisa verificar a carga efetiva e a possibilidade concreta de cumprir integralmente os dois vínculos.

### Para fixar
- Vedação alcança cargos, empregos e funções da Administração direta e indireta.
- Exceções: dois cargos de professor; professor + técnico/científico; dois vínculos de profissionais de saúde regulamentados.
- Todas as exceções exigem compatibilidade efetiva de horários.
- Servidor eleito prefeito afasta-se e pode optar; vereador só acumula se houver compatibilidade.
- Subsídio é parcela única; indenização legítima depende de ressarcimento real.

# SINTÉTICO

- **Regra**: acumulação remunerada de vínculos públicos é vedada pela CF, art. 37, XVI e XVII.
- **Abrangência**: inclui cargos, empregos e funções na Administração direta e indireta, inclusive controladas pelo Estado.
- **Professor**: pode acumular dois cargos de professor se os horários forem compatíveis.
- **Professor e outro vínculo**: admite-se um cargo docente com outro técnico ou científico, igualmente com horários compatíveis.
- **Saúde**: dois vínculos privativos de profissionais de saúde com profissões regulamentadas podem ser acumulados.
- **Mandato**: prefeito e parlamentares em geral se afastam; vereador mantém vínculo se horários forem compatíveis e pode optar pela remuneração se incompatíveis.
- **Subsídio**: parcela única exclui acréscimos remuneratórios; a natureza da verba prevalece sobre o nome dado pela norma.
- **Emprego privado**: a vedação constitucional de acumulação pública não proíbe automaticamente vínculo público com emprego particular.

# NOTAS

O trecho detalha o exercício de mandatos eletivos e o sistema de subsídio; a aplicação a militares segue as regras constitucionais específicas, não transcritas integralmente neste resumo.
