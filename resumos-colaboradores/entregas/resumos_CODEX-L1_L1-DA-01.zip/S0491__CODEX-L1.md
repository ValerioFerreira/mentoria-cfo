---
id: S0491
agente: CODEX-L1
materia: Direito Administrativo
aula: Aula 09 — Agentes públicos: espécies e classificação, poderes, deveres e prerrogativas, cargo, emprego e função
trecho: direito-administrativo/a09/s15
paginas_lidas: 153-163
---
# ANALÍTICO

Efetividade, estabilidade e vitaliciedade são institutos diferentes. O trecho trata da aquisição e perda da estabilidade, da proteção mais intensa de algumas carreiras e de formas de retorno ao serviço após invalidação ou mudança de situação funcional.

### Efetividade e estabilidade

**Efetividade** é atributo do cargo provido em caráter permanente após concurso; não significa, por si só, que o servidor já seja estável. A **estabilidade** é garantia do servidor ocupante de cargo efetivo após três anos de exercício e aprovação em avaliação especial de desempenho por comissão (CF, art. 41). Estágio probatório é período de avaliação no cargo; apesar da distinção conceitual, STF alinhou sua duração ao prazo constitucional de três anos.

Estabilidade não é permanência absoluta. Servidor estável perde o cargo por sentença judicial transitada em julgado, processo administrativo com ampla defesa, avaliação periódica de desempenho na forma de lei complementar ou redução de despesa com pessoal nos termos do art. 169, § 4º. Demissão é sanção por falta; exoneração não tem, necessariamente, caráter punitivo.

### Vitaliciedade e retorno

**Vitaliciedade** é garantia funcional mais forte, reservada às carreiras indicadas na Constituição. Adquire-se após dois anos de exercício para magistrados e membros do Ministério Público em primeiro grau, com avaliação, e desde a posse nas hipóteses constitucionais específicas. A perda do cargo exige sentença judicial transitada em julgado, diferentemente das hipóteses de perda da estabilidade.

Se a demissão for invalidada, o servidor estável é **reintegrado**. O ocupante atual da vaga, se estável, pode ser reconduzido ao cargo de origem, aproveitado em outro ou posto em disponibilidade, conforme art. 41, § 2º. **Recondução** também ocorre quando o servidor estável reprova em estágio probatório de outro cargo ou quando o anterior ocupante é reintegrado. **Aproveitamento** é o retorno do servidor em disponibilidade a cargo compatível.

### Para fixar
- Efetividade refere-se ao cargo; estabilidade é garantia adquirida pelo servidor.
- Estabilidade: cargo efetivo, três anos e avaliação especial.
- Há quatro hipóteses constitucionais de perda do cargo estável.
- Vitaliciedade é mais intensa e só se perde por decisão judicial definitiva.
- Reintegração resulta da invalidação da demissão.
- Recondução retorna servidor estável ao cargo anterior; aproveitamento retorna quem estava disponível.

# SINTÉTICO

- **Efetividade**: característica do cargo de provimento permanente; não equivale automaticamente à estabilidade do servidor.
- **Estabilidade**: exige cargo efetivo, três anos de exercício e avaliação especial (CF, art. 41).
- **Estágio probatório**: período de avaliação no cargo; STF o alinha ao prazo de três anos para estabilidade.
- **Perda do cargo estável**: sentença definitiva, processo disciplinar com defesa, avaliação periódica prevista em lei complementar ou redução de despesa nos termos do art. 169.
- **Vitaliciedade**: garantia de certas carreiras; perda depende de sentença transitada em julgado.
- **Reintegração**: retorno após anulação da demissão, com ressarcimento conforme a disciplina aplicável.
- **Recondução**: servidor estável volta ao cargo anterior, inclusive por reprovação no novo estágio ou reintegração de seu titular.
- **Aproveitamento**: retorno a cargo compatível de servidor que estava em disponibilidade.

# NOTAS

nenhuma
